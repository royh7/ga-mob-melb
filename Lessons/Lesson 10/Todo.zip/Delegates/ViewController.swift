//
//  ViewController.swift
//  Delegates
//
//  Created by Antonio de Perio on 10/12/2015.
//  Copyright © 2015 Workshop. All rights reserved.
//

import UIKit
//
//protocol AddViewControllerDelegate{
//    
//    func addItem()
//}

class ViewController: UIViewController {
    
//    var delegate: AddViewControllerDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func addToDo(sender: AnyObject) {
        
//        self.delegate!.addItem()
        
    }
}

